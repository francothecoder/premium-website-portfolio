<?php
header('Content-Type: application/json');
if($_SERVER['REQUEST_METHOD'] !== 'POST'){
  echo json_encode(['success'=>false,'message'=>'Invalid method']); exit;
}
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');
if(!$name || !$email || !$message){
  echo json_encode(['success'=>false,'message'=>'Please complete all fields']); exit;
}
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
  echo json_encode(['success'=>false,'message'=>'Invalid email']); exit;
}
// configure recipient
$to = 'your-email@example.com'; // <- change this
$subject = "Website contact from $name";
$body = "Name: $name\nEmail: $email\n\nMessage:\n$message";
$headers = 'From: no-reply@yourdomain.com' . "\r\n" . 'Reply-To: '.$email;
$sent = mail($to, $subject, $body, $headers);
if($sent){
  echo json_encode(['success'=>true,'message'=>'Message sent — thank you!']);
} else {
  echo json_encode(['success'=>false,'message'=>'Unable to send message from this server. Configure PHP mail or use SMTP.']);
}
?>