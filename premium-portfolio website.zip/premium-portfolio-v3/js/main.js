document.addEventListener('DOMContentLoaded', function() {
  // ===== AOS init =====
  AOS.init({ once: true, duration: 800 });

  // ===== Typed.js for hero subtitle =====
  if (window.Typed) {
    new Typed('#typed-text', {
      strings: ['Product Designer', 'Web Designer', 'UI/UX Enthusiast'],
      typeSpeed: 60,
      backSpeed: 40,
      loop: true
    });
  }

  // ===== Vanilla Tilt =====
  document.querySelectorAll('[data-tilt]').forEach(function(el) {
    VanillaTilt.init(el, { max: 8, speed: 400 });
  });

  // ===== Dark / Light Mode Toggle =====
  const darkModeBtn = document.getElementById('darkModeToggle');

  function setDarkMode(enabled) {
    if (enabled) {
      document.body.classList.add('dark-mode');
      darkModeBtn.textContent = '☀️'; // sun icon for light
    } else {
      document.body.classList.remove('dark-mode');
      darkModeBtn.textContent = '🌙'; // moon icon for dark
    }
    try {
      localStorage.setItem('darkMode', enabled ? '1' : '0');
    } catch (e) {}
  }

  // Initialize dark mode from storage
  try {
    if (localStorage.getItem('darkMode') === '1') setDarkMode(true);
  } catch (e) {}

  // Toggle on click
  if (darkModeBtn) {
    darkModeBtn.addEventListener('click', () => {
      setDarkMode(!document.body.classList.contains('dark-mode'));
    });
  }

  // ===== Portfolio filters =====
  document.querySelectorAll('.filter').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.filter').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const sel = btn.dataset.filter;
      document.querySelectorAll('#grid > div').forEach(function(card) {
        card.style.display = sel === '*' || card.dataset.category === sel ? 'block' : 'none';
      });
    });
  });

  // ===== Contact form AJAX =====
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const form = e.target;
      const data = new FormData(form);
      fetch(form.action, { method: 'POST', body: data })
        .then(res => res.json())
        .then(json => {
          const el = document.getElementById('formResult');
          el.style.display = 'block';
          el.innerText = json.message || 'Sent';
          el.className = json.success ? 'alert alert-success mt-3' : 'alert alert-danger mt-3';
        })
        .catch(() => {
          const el = document.getElementById('formResult');
          el.style.display = 'block';
          el.innerText = 'Server error';
          el.className = 'alert alert-danger mt-3';
        });
    });
  }
});
